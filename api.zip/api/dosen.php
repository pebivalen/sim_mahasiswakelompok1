<?php
require_once dirname(__DIR__) . '/db.php';
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-API-Key');
header('Cache-Control: no-store');
function response($code,$body){ http_response_code($code); echo json_encode($body, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
if ($_SERVER['REQUEST_METHOD']==='OPTIONS') { http_response_code(204); exit; }
$method=$_SERVER['REQUEST_METHOD'];
if (!in_array($method,['GET','POST','PUT','DELETE'],true)) response(405,['status'=>false,'message'=>'Method tidak didukung']);
if ($method!=='GET') {
  $key=$_SERVER['HTTP_X_API_KEY'] ?? '';
  if (!defined('API_KEY') || API_KEY==='GANTI_API_KEY_DENGAN_STRING_ACAK_PANJANG' || !hash_equals(API_KEY,$key)) response(401,['status'=>false,'message'=>'API key tidak valid. Atur API_KEY di config.php dan kirim header X-API-Key.']);
}
function cleanval($data,$key,$max=255){ return substr(trim((string)($data[$key]??'')),0,$max); }
if ($method==='GET') {
  $id=(int)($_GET['id']??0); $q=trim($_GET['q']??'');
  if ($id>0) {
    $st=$conn->prepare('SELECT d.id_dosen,d.nomor_registrasi,d.nuptk,d.nama,d.nip,d.jabatan_fungsional,d.kepangkatan,d.pendidikan_terakhir,d.rumpun_ilmu,d.status_serdos,d.status_pegawai,d.ikatan_kerja,d.status_aktivitas,p.nama_program_studi,f.nama_fakultas FROM dosen d LEFT JOIN program_studi p ON p.id_program_studi=d.id_program_studi LEFT JOIN fakultas f ON f.id_fakultas=p.id_fakultas WHERE d.id_dosen=?');
    $st->bind_param('i',$id);$st->execute();$row=$st->get_result()->fetch_assoc();
    if(!$row) response(404,['status'=>false,'message'=>'Data dosen tidak ditemukan']);
    response(200,['status'=>true,'data'=>$row]);
  }
  if($q!=='') {
    $like='%'.$q.'%'; $st=$conn->prepare('SELECT d.id_dosen,d.nomor_registrasi,d.nuptk,d.nama,d.nip,d.jabatan_fungsional,d.kepangkatan,d.pendidikan_terakhir,d.rumpun_ilmu,d.status_serdos,d.status_pegawai,d.ikatan_kerja,d.status_aktivitas,p.nama_program_studi,f.nama_fakultas FROM dosen d LEFT JOIN program_studi p ON p.id_program_studi=d.id_program_studi LEFT JOIN fakultas f ON f.id_fakultas=p.id_fakultas WHERE d.nama LIKE ? OR d.nip LIKE ? OR d.nomor_registrasi LIKE ? ORDER BY d.nama LIMIT 500');
    $st->bind_param('sss',$like,$like,$like);$st->execute();$res=$st->get_result();
  } else {
    $res=$conn->query('SELECT d.id_dosen,d.nomor_registrasi,d.nuptk,d.nama,d.nip,d.jabatan_fungsional,d.kepangkatan,d.pendidikan_terakhir,d.rumpun_ilmu,d.status_serdos,d.status_pegawai,d.ikatan_kerja,d.status_aktivitas,p.nama_program_studi,f.nama_fakultas FROM dosen d LEFT JOIN program_studi p ON p.id_program_studi=d.id_program_studi LEFT JOIN fakultas f ON f.id_fakultas=p.id_fakultas ORDER BY d.nama LIMIT 500');
  }
  $data=[]; if($res) while($r=$res->fetch_assoc()) $data[]=$r;
  response(200,['status'=>true,'count'=>count($data),'data'=>$data]);
}
$raw=file_get_contents('php://input'); $input=json_decode($raw,true);
if (!is_array($input)) response(400,['status'=>false,'message'=>'Body harus berupa JSON object']);
if ($method==='POST') {
  $nama=cleanval($input,'nama');
  if($nama==='') response(422,['status'=>false,'message'=>'Kolom nama wajib diisi']);
  $reg=cleanval($input,'nomor_registrasi');$nuptk=cleanval($input,'nuptk');$nip=cleanval($input,'nip');
  $jab=cleanval($input,'jabatan_fungsional');$pangkat=cleanval($input,'kepangkatan');$pend=cleanval($input,'pendidikan_terakhir');
  $rumpun=cleanval($input,'rumpun_ilmu');$serdos=cleanval($input,'status_serdos')?:'Belum';$pegawai=cleanval($input,'status_pegawai')?:'Tetap';
  $ikatan=cleanval($input,'ikatan_kerja');$aktiv=cleanval($input,'status_aktivitas')?:'Aktif';$prodi=(int)($input['id_program_studi']??0);
  $st=$conn->prepare('INSERT INTO dosen(nomor_registrasi,nuptk,nama,nip,jabatan_fungsional,kepangkatan,pendidikan_terakhir,rumpun_ilmu,status_serdos,status_pegawai,ikatan_kerja,status_aktivitas,id_program_studi) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)');
  $st->bind_param('ssssssssssssi',$reg,$nuptk,$nama,$nip,$jab,$pangkat,$pend,$rumpun,$serdos,$pegawai,$ikatan,$aktiv,$prodi);
  if(!$st->execute()) response(500,['status'=>false,'message'=>'Gagal menyimpan data']);
  response(201,['status'=>true,'message'=>'Data dosen ditambahkan','id'=>$conn->insert_id]);
}
$id=(int)($_GET['id']??0); if($id<1) response(422,['status'=>false,'message'=>'Parameter id wajib untuk PUT/DELETE']);
if($method==='DELETE') {
  $st=$conn->prepare('DELETE FROM dosen WHERE id_dosen=?');$st->bind_param('i',$id);$st->execute();
  if($st->affected_rows<1) response(404,['status'=>false,'message'=>'Data tidak ditemukan']);
  response(200,['status'=>true,'message'=>'Data dosen dihapus']);
}
if($method==='PUT') {
  $fields=['nomor_registrasi','nuptk','nama','nip','jabatan_fungsional','kepangkatan','pendidikan_terakhir','rumpun_ilmu','status_serdos','status_pegawai','ikatan_kerja','status_aktivitas'];
  $sets=[];$types='';$vals=[];
  foreach($fields as $f) if(array_key_exists($f,$input)) { $sets[]="`$f`=?";$types.='s';$vals[]=cleanval($input,$f,500); }
  if(array_key_exists('id_program_studi',$input)) {$sets[]='id_program_studi=?';$types.='i';$vals[]=(int)$input['id_program_studi'];}
  if(!$sets) response(422,['status'=>false,'message'=>'Tidak ada kolom yang diperbarui']);
  $types.='i';$vals[]=$id;$sql='UPDATE dosen SET '.implode(',',$sets).' WHERE id_dosen=?';
  $st=$conn->prepare($sql);$st->bind_param($types,...$vals);$st->execute();
  if($st->affected_rows<0) response(500,['status'=>false,'message'=>'Gagal memperbarui data']);
  response(200,['status'=>true,'message'=>'Permintaan pembaruan diproses']);
}
